package br.dev.priscila.primeiro_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiroJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
