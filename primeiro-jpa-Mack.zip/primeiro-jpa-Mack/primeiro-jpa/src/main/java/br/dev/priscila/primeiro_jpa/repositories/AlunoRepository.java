package br.dev.priscila.primeiro_jpa.repositories;

// import java.util.List;

import org.springframework.data.repository.CrudRepository;
import br.dev.priscila.primeiro_jpa.entities.Aluno;

public interface AlunoRepository extends CrudRepository <Aluno, Long>{

    // public List<Aluno> findByNomeOrderByRa(String nome, long ra){}
    
}
