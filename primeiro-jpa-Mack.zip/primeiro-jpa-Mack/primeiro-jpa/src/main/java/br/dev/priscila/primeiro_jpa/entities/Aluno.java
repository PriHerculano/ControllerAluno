package br.dev.priscila.primeiro_jpa.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Aluno {
    private String nome;
    @Id
    private long ra;

    public Aluno(){}
    
    public Aluno(String nome, long ra){
        this.nome = nome;
        this.ra = ra;
    }

    public String getNome() {
        return nome;
    }

    public long getRa() {
        return ra;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setRa(long ra) {
        this.ra = ra;
    }
}
